from app.machine import m_execute

def run():
  print(m_execute())
