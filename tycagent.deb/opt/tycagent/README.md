```bash
```bash
curl -u admin:123456 4linuxpainel.mixcloud.io/test1/installer.sh
```
